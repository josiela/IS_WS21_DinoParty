# IS_WS21_DinoParty
Semesterprojekt für das Fach Interaktive Systeme im WiSe 2021/2022
